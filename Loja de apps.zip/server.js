const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');
const cors = require('cors');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = 'sua_chave_secreta_aqui';

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Configuração do multer para upload de arquivos
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = 'uploads/';
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 100 * 1024 * 1024 // 100MB
  },
  fileFilter: (req, file, cb) => {
    if (file.fieldname === 'apk' && file.mimetype === 'application/vnd.android.package-archive') {
      cb(null, true);
    } else if (file.fieldname === 'logo' && file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Tipo de arquivo não permitido'), false);
    }
  }
});

// Inicializar banco de dados SQLite
const db = new sqlite3.Database('loja_apps.db', (err) => {
  if (err) {
    console.error('Erro ao conectar com o banco de dados:', err.message);
  } else {
    console.log('Conectado ao banco de dados SQLite');
    initializeDatabase();
  }
});

// Inicializar tabelas do banco de dados
function initializeDatabase() {
  // Tabela de usuários
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      is_developer BOOLEAN DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Tabela de aplicativos
  db.run(`
    CREATE TABLE IF NOT EXISTS apps (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      version TEXT NOT NULL,
      description TEXT NOT NULL,
      logo_path TEXT,
      apk_path TEXT NOT NULL,
      developer_id INTEGER,
      download_count INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (developer_id) REFERENCES users (id)
    )
  `);

  // Tabela de avaliações
  db.run(`
    CREATE TABLE IF NOT EXISTS ratings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      app_id INTEGER,
      user_id INTEGER,
      rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
      comment TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (app_id) REFERENCES apps (id),
      FOREIGN KEY (user_id) REFERENCES users (id),
      UNIQUE(app_id, user_id)
    )
  `);
}

// Middleware de autenticação
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Token de acesso necessário' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Token inválido' });
    }
    req.user = user;
    next();
  });
};

// Rotas de autenticação
app.post('/api/register', async (req, res) => {
  try {
    const { name, email, password, isDeveloper } = req.body;

    // Verificar se o email já existe
    db.get('SELECT id FROM users WHERE email = ?', [email], async (err, row) => {
      if (err) {
        return res.status(500).json({ error: 'Erro interno do servidor' });
      }

      if (row) {
        return res.status(400).json({ error: 'Email já cadastrado' });
      }

      // Hash da senha
      const hashedPassword = await bcrypt.hash(password, 10);

      // Inserir usuário no banco
      db.run(
        'INSERT INTO users (name, email, password, is_developer) VALUES (?, ?, ?, ?)',
        [name, email, hashedPassword, isDeveloper ? 1 : 0],
        function(err) {
          if (err) {
            return res.status(500).json({ error: 'Erro ao criar usuário' });
          }

          const token = jwt.sign(
            { id: this.lastID, email, isDeveloper },
            JWT_SECRET,
            { expiresIn: '24h' }
          );

          res.json({
            message: 'Usuário criado com sucesso',
            token,
            user: { id: this.lastID, name, email, isDeveloper }
          });
        }
      );
    });
  } catch (error) {
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;

  db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
    if (err) {
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }

    if (!user) {
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, isDeveloper: user.is_developer },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      message: 'Login realizado com sucesso',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        isDeveloper: user.is_developer
      }
    });
  });
});

// Rotas de aplicativos
app.get('/api/apps', (req, res) => {
  const { search, limit = 10, offset = 0 } = req.query;
  
  let query = `
    SELECT a.*, u.name as developer_name,
    COALESCE(AVG(r.rating), 0) as average_rating,
    COUNT(r.id) as rating_count
    FROM apps a
    LEFT JOIN users u ON a.developer_id = u.id
    LEFT JOIN ratings r ON a.id = r.app_id
  `;
  
  let params = [];
  
  if (search) {
    query += ' WHERE a.name LIKE ? OR a.description LIKE ?';
    params.push(`%${search}%`, `%${search}%`);
  }
  
  query += `
    GROUP BY a.id
    ORDER BY a.created_at DESC
    LIMIT ? OFFSET ?
  `;
  
  params.push(parseInt(limit), parseInt(offset));
  
  db.all(query, params, (err, rows) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao buscar aplicativos' });
    }
    res.json(rows);
  });
});

app.get('/api/apps/recent', (req, res) => {
  const limit = req.query.limit || 5;
  
  const query = `
    SELECT a.*, u.name as developer_name,
    COALESCE(AVG(r.rating), 0) as average_rating,
    COUNT(r.id) as rating_count
    FROM apps a
    LEFT JOIN users u ON a.developer_id = u.id
    LEFT JOIN ratings r ON a.id = r.app_id
    GROUP BY a.id
    ORDER BY a.created_at DESC
    LIMIT ?
  `;
  
  db.all(query, [limit], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao buscar aplicativos recentes' });
    }
    res.json(rows);
  });
});

app.get('/api/apps/:id', (req, res) => {
  const appId = req.params.id;
  
  const query = `
    SELECT a.*, u.name as developer_name,
    COALESCE(AVG(r.rating), 0) as average_rating,
    COUNT(r.id) as rating_count
    FROM apps a
    LEFT JOIN users u ON a.developer_id = u.id
    LEFT JOIN ratings r ON a.id = r.app_id
    WHERE a.id = ?
    GROUP BY a.id
  `;
  
  db.get(query, [appId], (err, row) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao buscar aplicativo' });
    }
    
    if (!row) {
      return res.status(404).json({ error: 'Aplicativo não encontrado' });
    }
    
    res.json(row);
  });
});

app.post('/api/apps', authenticateToken, upload.fields([
  { name: 'logo', maxCount: 1 },
  { name: 'apk', maxCount: 1 }
]), (req, res) => {
  try {
    const { name, version, description } = req.body;
    const logoFile = req.files.logo ? req.files.logo[0] : null;
    const apkFile = req.files.apk ? req.files.apk[0] : null;

    if (!apkFile) {
      return res.status(400).json({ error: 'Arquivo APK é obrigatório' });
    }

    const logoPath = logoFile ? logoFile.path : null;
    const apkPath = apkFile.path;

    db.run(
      'INSERT INTO apps (name, version, description, logo_path, apk_path, developer_id) VALUES (?, ?, ?, ?, ?, ?)',
      [name, version, description, logoPath, apkPath, req.user.id],
      function(err) {
        if (err) {
          return res.status(500).json({ error: 'Erro ao criar aplicativo' });
        }

        res.json({
          message: 'Aplicativo criado com sucesso',
          app: {
            id: this.lastID,
            name,
            version,
            description,
            logoPath,
            apkPath
          }
        });
      }
    );
  } catch (error) {
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Rotas de avaliações
app.post('/api/apps/:id/rate', authenticateToken, (req, res) => {
  const appId = req.params.id;
  const { rating, comment } = req.body;

  if (rating < 1 || rating > 5) {
    return res.status(400).json({ error: 'Avaliação deve ser entre 1 e 5' });
  }

  db.run(
    'INSERT OR REPLACE INTO ratings (app_id, user_id, rating, comment) VALUES (?, ?, ?, ?)',
    [appId, req.user.id, rating, comment],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Erro ao salvar avaliação' });
      }

      res.json({ message: 'Avaliação salva com sucesso' });
    }
  );
});

app.get('/api/apps/:id/ratings', (req, res) => {
  const appId = req.params.id;
  
  const query = `
    SELECT r.*, u.name as user_name
    FROM ratings r
    JOIN users u ON r.user_id = u.id
    WHERE r.app_id = ?
    ORDER BY r.created_at DESC
  `;
  
  db.all(query, [appId], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao buscar avaliações' });
    }
    res.json(rows);
  });
});

// Rota para download de APK
app.get('/api/apps/:id/download', (req, res) => {
  const appId = req.params.id;
  
  db.get('SELECT apk_path, name FROM apps WHERE id = ?', [appId], (err, row) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao buscar aplicativo' });
    }
    
    if (!row) {
      return res.status(404).json({ error: 'Aplicativo não encontrado' });
    }
    
    // Incrementar contador de downloads
    db.run('UPDATE apps SET download_count = download_count + 1 WHERE id = ?', [appId]);
    
    // Enviar arquivo
    const filePath = path.join(__dirname, row.apk_path);
    const fileName = `${row.name}.apk`;
    
    res.download(filePath, fileName, (err) => {
      if (err) {
        console.error('Erro ao fazer download:', err);
        res.status(500).json({ error: 'Erro ao fazer download do arquivo' });
      }
    });
  });
});

// Servir arquivos estáticos
app.use('/uploads', express.static('uploads'));

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
