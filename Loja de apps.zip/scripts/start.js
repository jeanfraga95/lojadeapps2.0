const { spawn } = require('child_process');
const path = require('path');

console.log('🚀 Iniciando Loja de Apps Android...\n');

// Iniciar servidor backend
console.log('📡 Iniciando servidor backend...');
const server = spawn('node', ['server.js'], {
  stdio: 'inherit',
  cwd: path.join(__dirname, '..')
});

// Aguardar um pouco para o servidor inicializar
setTimeout(() => {
  console.log('⚛️  Iniciando frontend React...');
  
  // Iniciar frontend React
  const frontend = spawn('npm', ['start'], {
    stdio: 'inherit',
    cwd: path.join(__dirname, '..'),
    shell: true
  });

  // Gerenciar encerramento
  process.on('SIGINT', () => {
    console.log('\n🛑 Encerrando aplicação...');
    server.kill();
    frontend.kill();
    process.exit(0);
  });

}, 2000);

// Tratar erros do servidor
server.on('error', (err) => {
  console.error('❌ Erro no servidor:', err);
});

server.on('exit', (code) => {
  if (code !== 0) {
    console.error(`❌ Servidor encerrado com código ${code}`);
  }
});
