# 📱 Guia de Instalação - Loja de Apps Android

## 🚀 Início Rápido

### 1. Instalar Dependências
```bash
npm install
```

### 2. Iniciar Aplicação (Recomendado)
```bash
npm run dev
```
Este comando inicia automaticamente o servidor backend e o frontend React.

### 3. Acessar a Aplicação
- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:5000

---

## 🔧 Instalação Manual (Passo a Passo)

### Passo 1: Instalar Dependências
```bash
# Instalar todas as dependências do projeto
npm install
```

### Passo 2: Iniciar Servidor Backend
```bash
# Em um terminal
npm run server
# ou
node server.js
```

### Passo 3: Iniciar Frontend React
```bash
# Em outro terminal
npm start
```

---

## 📋 Pré-requisitos

- **Node.js**: Versão 16 ou superior
- **npm**: Versão 8 ou superior
- **Sistema Operacional**: Windows, macOS ou Linux

### Verificar Instalação
```bash
node --version
npm --version
```

---

## 🗂️ Estrutura de Arquivos

```
loja-apps-android/
├── 📁 public/           # Arquivos públicos
├── 📁 src/              # Código fonte React
│   ├── 📁 components/   # Componentes React
│   └── 📁 contexts/     # Context API
├── 📁 uploads/          # Arquivos enviados (criado automaticamente)
├── 📄 server.js         # Servidor Node.js
├── 📄 package.json      # Dependências e scripts
└── 📄 README.md         # Documentação
```

---

## 🛠️ Scripts Disponíveis

| Comando | Descrição |
|---------|-----------|
| `npm run dev` | Inicia backend + frontend automaticamente |
| `npm run server` | Inicia apenas o servidor backend |
| `npm start` | Inicia apenas o frontend React |
| `npm run build` | Cria build de produção |
| `npm test` | Executa testes |

---

## 🗄️ Banco de Dados

O sistema utiliza **SQLite** que é criado automaticamente na primeira execução.

### Tabelas Criadas Automaticamente:
- `users` - Usuários e desenvolvedores
- `apps` - Aplicativos publicados  
- `ratings` - Avaliações dos aplicativos

### Localização do Banco:
- Arquivo: `loja_apps.db` (criado na raiz do projeto)

---

## 📁 Upload de Arquivos

Os arquivos enviados são salvos na pasta `uploads/`:
- **APKs**: `uploads/apk-*.apk`
- **Logos**: `uploads/logo-*.jpg/png`

### Configurações de Upload:
- **APK**: Máximo 100MB
- **Logo**: Máximo 10MB (PNG, JPG, GIF)

---

## 🔐 Primeiro Acesso

### 1. Cadastrar Usuário Comum
- Acesse http://localhost:3000
- Clique em "Cadastrar"
- Preencha os dados
- **NÃO** marque "Sou desenvolvedor"

### 2. Cadastrar Desenvolvedor
- Acesse http://localhost:3000
- Clique em "Cadastrar"  
- Preencha os dados
- **MARQUE** "Sou desenvolvedor e quero publicar aplicativos"

### 3. Fazer Login
- Use email e senha cadastrados
- Acesse todas as funcionalidades

---

## 🚨 Solução de Problemas

### Erro: "Porta já está em uso"
```bash
# Encontrar processo usando a porta
netstat -ano | findstr :3000
netstat -ano | findstr :5000

# Encerrar processo (Windows)
taskkill /PID <numero_do_processo> /F
```

### Erro: "Module not found"
```bash
# Reinstalar dependências
rm -rf node_modules
npm install
```

### Erro: "Database locked"
```bash
# Encerrar todas as instâncias e reiniciar
# O SQLite pode estar sendo usado por outro processo
```

### Erro: "Upload failed"
```bash
# Verificar se a pasta uploads/ existe
mkdir uploads
```

---

## 🌐 Acessar de Outros Dispositivos

Para acessar de outros dispositivos na mesma rede:

1. **Descobrir IP da máquina**:
```bash
# Windows
ipconfig

# macOS/Linux  
ifconfig
```

2. **Acessar via IP**:
- Frontend: `http://SEU_IP:3000`
- Backend: `http://SEU_IP:5000`

---

## 📱 Funcionalidades Testadas

### ✅ Usuário Comum
- [x] Cadastro e login
- [x] Busca de aplicativos
- [x] Visualização de detalhes
- [x] Download de APKs
- [x] Avaliação de aplicativos

### ✅ Desenvolvedor
- [x] Cadastro como desenvolvedor
- [x] Upload de APK
- [x] Upload de logo
- [x] Publicação de aplicativo
- [x] Visualização de downloads

---

## 🔄 Atualizações

Para atualizar o projeto:
```bash
git pull origin main
npm install
npm run dev
```

---

## 📞 Suporte

Se encontrar problemas:
1. Verifique se todas as dependências estão instaladas
2. Confirme se as portas 3000 e 5000 estão livres
3. Verifique os logs no terminal
4. Consulte a documentação no README.md

---

## 🎉 Pronto!

Sua loja de aplicativos Android está funcionando! 

**Acesse**: http://localhost:3000
contato@cloudjf.com.br