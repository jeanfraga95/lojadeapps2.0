import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';
import RatingModal from './RatingModal';

function AppDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [app, setApp] = useState(null);
  const [ratings, setRatings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showRatingModal, setShowRatingModal] = useState(false);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    fetchAppDetails();
    fetchRatings();
  }, [id]);

  const fetchAppDetails = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/apps/${id}`);
      setApp(response.data);
    } catch (error) {
      setError('Erro ao carregar aplicativo');
      console.error('Erro ao buscar app:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchRatings = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/apps/${id}/ratings`);
      setRatings(response.data);
    } catch (error) {
      console.error('Erro ao buscar avaliações:', error);
    }
  };

  const handleDownload = async () => {
    if (!user) {
      navigate('/login');
      return;
    }

    try {
      setDownloading(true);
      const response = await axios.get(`http://localhost:5000/api/apps/${id}/download`, {
        responseType: 'blob'
      });

      // Criar link de download
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `${app.name}.apk`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Erro ao fazer download:', error);
      alert('Erro ao fazer download do aplicativo');
    } finally {
      setDownloading(false);
    }
  };

  const handleRateApp = () => {
    if (!user) {
      navigate('/login');
      return;
    }
    setShowRatingModal(true);
  };

  const handleRatingSubmitted = () => {
    setShowRatingModal(false);
    fetchRatings();
    fetchAppDetails(); // Atualizar avaliação média
  };

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<i key={i} className="fas fa-star"></i>);
    }

    if (hasHalfStar) {
      stars.push(<i key="half" className="fas fa-star-half-alt"></i>);
    }

    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<i key={`empty-${i}`} className="far fa-star"></i>);
    }

    return stars;
  };

  if (loading) {
    return (
      <div className="loading">
        <div className="spinner"></div>
      </div>
    );
  }

  if (error || !app) {
    return (
      <div className="app-details-container">
        <div className="alert alert-danger">
          {error || 'Aplicativo não encontrado'}
        </div>
        <button 
          onClick={() => navigate('/')} 
          className="btn btn-primary"
        >
          <i className="fas fa-arrow-left"></i> Voltar
        </button>
      </div>
    );
  }

  return (
    <div className="app-details-container">
      <button 
        onClick={() => navigate('/')} 
        className="btn btn-secondary"
        style={{ marginBottom: '20px' }}
      >
        <i className="fas fa-arrow-left"></i> Voltar
      </button>

      <div className="app-details-header">
        <img
          src={app.logo_path ? `http://localhost:5000/${app.logo_path}` : '/api/placeholder/120/120'}
          alt={app.name}
          className="app-details-image"
          onError={(e) => {
            e.target.src = '/api/placeholder/120/120';
          }}
        />
        <div className="app-details-info">
          <h1 className="app-details-title">{app.name}</h1>
          <p className="app-details-version">Versão {app.version}</p>
          <p className="app-details-developer">Desenvolvido por {app.developer_name}</p>
          
          <div className="app-details-rating">
            <div className="app-details-stars">
              {renderStars(app.average_rating)}
            </div>
            <span className="app-details-rating-text">
              {app.average_rating > 0 
                ? `${app.average_rating.toFixed(1)} (${app.rating_count} avaliações)`
                : 'Sem avaliações'
              }
            </span>
          </div>

          <div className="app-details-actions">
            <button 
              onClick={handleDownload}
              disabled={downloading}
              className="btn btn-success"
            >
              {downloading ? (
                <>
                  <i className="fas fa-spinner fa-spin"></i> Baixando...
                </>
              ) : (
                <>
                  <i className="fas fa-download"></i> Baixar APK
                </>
              )}
            </button>
            <button 
              onClick={handleRateApp}
              className="btn btn-primary"
            >
              <i className="fas fa-star"></i> Avaliar
            </button>
          </div>
        </div>
      </div>

      <div className="app-details-description">
        <h3>Descrição</h3>
        <p>{app.description}</p>
      </div>

      <div className="ratings-section">
        <div className="ratings-header">
          <h3 className="ratings-title">Avaliações ({ratings.length})</h3>
        </div>

        {ratings.length === 0 ? (
          <p style={{ textAlign: 'center', color: '#666', padding: '20px' }}>
            Nenhuma avaliação ainda. Seja o primeiro a avaliar!
          </p>
        ) : (
          <div>
            {ratings.map(rating => (
              <div key={rating.id} className="rating-item">
                <div className="rating-user">{rating.user_name}</div>
                <div className="rating-stars">
                  {renderStars(rating.rating)}
                </div>
                {rating.comment && (
                  <div className="rating-comment">{rating.comment}</div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {showRatingModal && (
        <RatingModal
          appId={id}
          onClose={() => setShowRatingModal(false)}
          onSubmitted={handleRatingSubmitted}
        />
      )}
    </div>
  );
}

export default AppDetails;
