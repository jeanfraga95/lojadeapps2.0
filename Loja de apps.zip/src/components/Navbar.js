import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="navbar">
      <div className="container">
        <div className="navbar-content">
          <Link to="/" className="logo">
            <i className="fas fa-mobile-alt"></i> Loja de Apps
          </Link>
          
          <form onSubmit={handleSearch} className="search-container">
            <input
              type="text"
              placeholder="Buscar aplicativos..."
              className="search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <i className="fas fa-search search-icon"></i>
          </form>

          <div className="nav-links">
            {user ? (
              <>
                <span className="nav-link">
                  Olá, {user.name}
                </span>
                {user.isDeveloper && (
                  <Link to="/upload" className="nav-link">
                    <i className="fas fa-upload"></i> Subir App
                  </Link>
                )}
                <button onClick={handleLogout} className="btn btn-secondary">
                  <i className="fas fa-sign-out-alt"></i> Sair
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="nav-link">
                  <i className="fas fa-sign-in-alt"></i> Entrar
                </Link>
                <Link to="/register" className="btn btn-primary">
                  <i className="fas fa-user-plus"></i> Cadastrar
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
