import React, { useState } from 'react';
import axios from 'axios';

function RatingModal({ appId, onClose, onSubmitted }) {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (rating === 0) {
      setError('Por favor, selecione uma avaliação');
      return;
    }

    try {
      setLoading(true);
      setError('');

      const token = localStorage.getItem('token');
      await axios.post(
        `http://localhost:5000/api/apps/${appId}/rate`,
        { rating, comment },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      onSubmitted();
    } catch (error) {
      setError(error.response?.data?.error || 'Erro ao salvar avaliação');
    } finally {
      setLoading(false);
    }
  };

  const renderStars = (currentRating) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <span
          key={i}
          className={`star-input ${i <= currentRating ? 'active' : ''}`}
          onClick={() => setRating(i)}
          onMouseEnter={() => setRating(i)}
        >
          <i className="fas fa-star"></i>
        </span>
      );
    }
    return stars;
  };

  return (
    <div className="modal">
      <div className="modal-content">
        <div className="modal-header">
          <h3 className="modal-title">Avaliar Aplicativo</h3>
          <button className="modal-close" onClick={onClose}>
            <i className="fas fa-times"></i>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="modal-body">
          {error && (
            <div className="alert alert-danger">
              {error}
            </div>
          )}

          <div className="rating-modal">
            <h4>Avaliação</h4>
            <div 
              className="rating-stars-input"
              onMouseLeave={() => setRating(rating)}
            >
              {renderStars(rating)}
            </div>
            <p style={{ textAlign: 'center', color: '#666', marginTop: '10px' }}>
              {rating === 0 && 'Selecione uma avaliação'}
              {rating === 1 && 'Péssimo'}
              {rating === 2 && 'Ruim'}
              {rating === 3 && 'Regular'}
              {rating === 4 && 'Bom'}
              {rating === 5 && 'Excelente'}
            </p>
          </div>

          <div className="form-group">
            <label className="form-label">Comentário (opcional)</label>
            <textarea
              className="form-textarea"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Deixe um comentário sobre o aplicativo..."
              rows="4"
            />
          </div>
        </form>

        <div className="modal-footer">
          <button 
            type="button" 
            onClick={onClose}
            className="btn btn-secondary"
          >
            Cancelar
          </button>
          <button 
            type="submit"
            onClick={handleSubmit}
            disabled={loading || rating === 0}
            className="btn btn-primary"
          >
            {loading ? (
              <>
                <i className="fas fa-spinner fa-spin"></i> Salvando...
              </>
            ) : (
              <>
                <i className="fas fa-star"></i> Avaliar
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

export default RatingModal;
