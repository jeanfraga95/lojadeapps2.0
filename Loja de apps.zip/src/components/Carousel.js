import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

function Carousel({ apps }) {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (apps.length <= 1) return;

    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => 
        prevIndex === apps.length - 1 ? 0 : prevIndex + 1
      );
    }, 5000); // Muda a cada 5 segundos

    return () => clearInterval(interval);
  }, [apps.length]);

  const goToSlide = (index) => {
    setCurrentIndex(index);
  };

  const goToPrevious = () => {
    setCurrentIndex(currentIndex === 0 ? apps.length - 1 : currentIndex - 1);
  };

  const goToNext = () => {
    setCurrentIndex(currentIndex === apps.length - 1 ? 0 : currentIndex + 1);
  };

  if (apps.length === 0) return null;

  return (
    <div className="carousel">
      <div 
        className="carousel-inner"
        style={{ transform: `translateX(-${currentIndex * 100}%)` }}
      >
        {apps.map((app, index) => (
          <div key={app.id} className="carousel-item">
            <div style={{ position: 'relative' }}>
              <img
                src={app.logo_path ? `http://localhost:5000/${app.logo_path}` : '/api/placeholder/400/300'}
                alt={app.name}
                className="carousel-image"
                onError={(e) => {
                  e.target.src = '/api/placeholder/400/300';
                }}
              />
              <div className="carousel-caption">
                <h3 className="carousel-title">{app.name}</h3>
                <p className="carousel-description">{app.description}</p>
                <div style={{ marginTop: '20px' }}>
                  <Link 
                    to={`/app/${app.id}`} 
                    className="btn btn-primary"
                  >
                    <i className="fas fa-download"></i> Ver Detalhes
                  </Link>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Controles do carrossel */}
      {apps.length > 1 && (
        <>
          <button 
            className="carousel-control prev"
            onClick={goToPrevious}
            style={{
              position: 'absolute',
              left: '20px',
              top: '50%',
              transform: 'translateY(-50%)',
              background: 'rgba(0,0,0,0.5)',
              color: 'white',
              border: 'none',
              borderRadius: '50%',
              width: '50px',
              height: '50px',
              cursor: 'pointer',
              fontSize: '20px',
              zIndex: 10
            }}
          >
            <i className="fas fa-chevron-left"></i>
          </button>

          <button 
            className="carousel-control next"
            onClick={goToNext}
            style={{
              position: 'absolute',
              right: '20px',
              top: '50%',
              transform: 'translateY(-50%)',
              background: 'rgba(0,0,0,0.5)',
              color: 'white',
              border: 'none',
              borderRadius: '50%',
              width: '50px',
              height: '50px',
              cursor: 'pointer',
              fontSize: '20px',
              zIndex: 10
            }}
          >
            <i className="fas fa-chevron-right"></i>
          </button>

          {/* Indicadores */}
          <div 
            className="carousel-indicators"
            style={{
              position: 'absolute',
              bottom: '20px',
              left: '50%',
              transform: 'translateX(-50%)',
              display: 'flex',
              gap: '10px',
              zIndex: 10
            }}
          >
            {apps.map((_, index) => (
              <button
                key={index}
                className={`carousel-indicator ${index === currentIndex ? 'active' : ''}`}
                onClick={() => goToSlide(index)}
                style={{
                  width: '12px',
                  height: '12px',
                  borderRadius: '50%',
                  border: 'none',
                  background: index === currentIndex ? 'white' : 'rgba(255,255,255,0.5)',
                  cursor: 'pointer',
                  transition: 'background 0.3s ease'
                }}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default Carousel;
