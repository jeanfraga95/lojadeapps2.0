import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

function UploadApp() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    version: '',
    description: ''
  });
  const [logoFile, setLogoFile] = useState(null);
  const [apkFile, setApkFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleLogoChange = (e) => {
    const file = e.target.files[0];
    if (file && file.type.startsWith('image/')) {
      setLogoFile(file);
    } else {
      setError('Por favor, selecione um arquivo de imagem válido para o logo');
    }
  };

  const handleApkChange = (e) => {
    const file = e.target.files[0];
    if (file && file.type === 'application/vnd.android.package-archive') {
      setApkFile(file);
    } else {
      setError('Por favor, selecione um arquivo APK válido');
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.currentTarget.classList.add('dragover');
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.currentTarget.classList.remove('dragover');
  };

  const handleDrop = (e, type) => {
    e.preventDefault();
    e.currentTarget.classList.remove('dragover');
    
    const file = e.dataTransfer.files[0];
    if (!file) return;

    if (type === 'logo' && file.type.startsWith('image/')) {
      setLogoFile(file);
    } else if (type === 'apk' && file.type === 'application/vnd.android.package-archive') {
      setApkFile(file);
    } else {
      setError(`Por favor, selecione um arquivo ${type === 'logo' ? 'de imagem' : 'APK'} válido`);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!formData.name.trim()) {
      setError('Nome do aplicativo é obrigatório');
      return;
    }

    if (!formData.version.trim()) {
      setError('Versão é obrigatória');
      return;
    }

    if (!formData.description.trim()) {
      setError('Descrição é obrigatória');
      return;
    }

    if (!apkFile) {
      setError('Arquivo APK é obrigatório');
      return;
    }

    try {
      setLoading(true);

      const token = localStorage.getItem('token');
      const uploadData = new FormData();
      
      uploadData.append('name', formData.name);
      uploadData.append('version', formData.version);
      uploadData.append('description', formData.description);
      
      if (logoFile) {
        uploadData.append('logo', logoFile);
      }
      
      uploadData.append('apk', apkFile);

      const response = await axios.post(
        'http://localhost:5000/api/apps',
        uploadData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
            Authorization: `Bearer ${token}`
          }
        }
      );

      setSuccess('Aplicativo publicado com sucesso!');
      
      // Limpar formulário
      setFormData({ name: '', version: '', description: '' });
      setLogoFile(null);
      setApkFile(null);
      
      // Redirecionar após 2 segundos
      setTimeout(() => {
        navigate('/');
      }, 2000);

    } catch (error) {
      setError(error.response?.data?.error || 'Erro ao publicar aplicativo');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="upload-container">
      <div className="upload-form">
        <h1 className="upload-title">
          <i className="fas fa-upload"></i> Publicar Aplicativo
        </h1>

        {error && (
          <div className="alert alert-danger">
            {error}
          </div>
        )}

        {success && (
          <div className="alert alert-success">
            {success}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Nome do Aplicativo *</label>
            <input
              type="text"
              name="name"
              className="form-input"
              value={formData.name}
              onChange={handleInputChange}
              placeholder="Ex: Meu App Incrível"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Versão *</label>
            <input
              type="text"
              name="version"
              className="form-input"
              value={formData.version}
              onChange={handleInputChange}
              placeholder="Ex: 1.0.0"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Descrição *</label>
            <textarea
              name="description"
              className="form-textarea"
              value={formData.description}
              onChange={handleInputChange}
              placeholder="Descreva seu aplicativo, suas funcionalidades e recursos..."
              rows="4"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Logo do Aplicativo</label>
            <div
              className="upload-area"
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={(e) => handleDrop(e, 'logo')}
              onClick={() => document.getElementById('logo-input').click()}
            >
              <input
                id="logo-input"
                type="file"
                accept="image/*"
                onChange={handleLogoChange}
                className="file-input"
              />
              <div className="upload-icon">
                <i className="fas fa-image"></i>
              </div>
              <div className="upload-text">
                {logoFile ? logoFile.name : 'Clique ou arraste uma imagem aqui'}
              </div>
              <div className="upload-subtext">
                PNG, JPG, GIF até 10MB
              </div>
            </div>
            {logoFile && (
              <div className="upload-preview">
                <img
                  src={URL.createObjectURL(logoFile)}
                  alt="Preview"
                  className="upload-preview-image"
                />
                <div className="upload-preview-info">
                  <div className="upload-preview-name">{logoFile.name}</div>
                  <div className="upload-preview-size">
                    {(logoFile.size / 1024 / 1024).toFixed(2)} MB
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="form-group">
            <label className="form-label">Arquivo APK *</label>
            <div
              className="upload-area"
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={(e) => handleDrop(e, 'apk')}
              onClick={() => document.getElementById('apk-input').click()}
            >
              <input
                id="apk-input"
                type="file"
                accept=".apk"
                onChange={handleApkChange}
                className="file-input"
              />
              <div className="upload-icon">
                <i className="fas fa-mobile-alt"></i>
              </div>
              <div className="upload-text">
                {apkFile ? apkFile.name : 'Clique ou arraste um arquivo APK aqui'}
              </div>
              <div className="upload-subtext">
                Arquivo APK até 100MB
              </div>
            </div>
            {apkFile && (
              <div className="upload-preview">
                <div className="upload-preview-image" style={{ 
                  background: '#667eea', 
                  color: 'white', 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center',
                  fontSize: '24px'
                }}>
                  <i className="fas fa-mobile-alt"></i>
                </div>
                <div className="upload-preview-info">
                  <div className="upload-preview-name">{apkFile.name}</div>
                  <div className="upload-preview-size">
                    {(apkFile.size / 1024 / 1024).toFixed(2)} MB
                  </div>
                </div>
              </div>
            )}
          </div>

          <div style={{ display: 'flex', gap: '15px', marginTop: '30px' }}>
            <button
              type="button"
              onClick={() => navigate('/')}
              className="btn btn-secondary"
            >
              <i className="fas fa-arrow-left"></i> Cancelar
            </button>
            <button
              type="submit"
              disabled={loading}
              className="btn btn-primary"
              style={{ flex: 1 }}
            >
              {loading ? (
                <>
                  <i className="fas fa-spinner fa-spin"></i> Publicando...
                </>
              ) : (
                <>
                  <i className="fas fa-upload"></i> Publicar Aplicativo
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default UploadApp;
