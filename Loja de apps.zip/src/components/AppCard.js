import React from 'react';
import { Link } from 'react-router-dom';

function AppCard({ app }) {
  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<i key={i} className="fas fa-star"></i>);
    }

    if (hasHalfStar) {
      stars.push(<i key="half" className="fas fa-star-half-alt"></i>);
    }

    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<i key={`empty-${i}`} className="far fa-star"></i>);
    }

    return stars;
  };

  return (
    <div className="app-card">
      <img
        src={app.logo_path ? `http://localhost:5000/${app.logo_path}` : '/api/placeholder/280/200'}
        alt={app.name}
        className="app-image"
        onError={(e) => {
          e.target.src = '/api/placeholder/280/200';
        }}
      />
      <div className="app-info">
        <h3 className="app-title">{app.name}</h3>
        <p className="app-version">Versão {app.version}</p>
        <p className="app-description">
          {app.description.length > 100 
            ? `${app.description.substring(0, 100)}...` 
            : app.description
          }
        </p>
        
        <div className="app-rating">
          <div className="stars">
            {renderStars(app.average_rating)}
          </div>
          <span className="rating-text">
            {app.average_rating > 0 
              ? `${app.average_rating.toFixed(1)} (${app.rating_count} avaliações)`
              : 'Sem avaliações'
            }
          </span>
        </div>

        <div className="app-actions">
          <Link 
            to={`/app/${app.id}`} 
            className="btn-download"
          >
            <i className="fas fa-download"></i> Baixar
          </Link>
          <Link 
            to={`/app/${app.id}`} 
            className="btn-rating"
          >
            <i className="fas fa-star"></i> Avaliar
          </Link>
        </div>
      </div>
    </div>
  );
}

export default AppCard;
