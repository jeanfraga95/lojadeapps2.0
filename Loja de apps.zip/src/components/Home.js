import React, { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import axios from 'axios';
import AppCard from './AppCard';
import Carousel from './Carousel';

function Home() {
  const [apps, setApps] = useState([]);
  const [recentApps, setRecentApps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get('search') || '';

  useEffect(() => {
    fetchApps();
    fetchRecentApps();
  }, [searchQuery]);

  const fetchApps = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (searchQuery) {
        params.append('search', searchQuery);
      }
      params.append('limit', '20');
      
      const response = await axios.get(`http://localhost:5000/api/apps?${params}`);
      setApps(response.data);
    } catch (error) {
      setError('Erro ao carregar aplicativos');
      console.error('Erro ao buscar apps:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchRecentApps = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/apps/recent?limit=5');
      setRecentApps(response.data);
    } catch (error) {
      console.error('Erro ao buscar apps recentes:', error);
    }
  };

  if (loading) {
    return (
      <div className="loading">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div>
      {/* Hero Section */}
      {!searchQuery && (
        <section className="hero-section">
          <div className="container">
            <h1 className="hero-title">Bem-vindo à Loja de Apps</h1>
            <p className="hero-subtitle">
              Descubra e baixe os melhores aplicativos Android
            </p>
            <div className="hero-actions">
              <Link to="/register" className="btn btn-primary">
                <i className="fas fa-user-plus"></i> Cadastrar
              </Link>
              <Link to="/login" className="btn btn-secondary">
                <i className="fas fa-sign-in-alt"></i> Entrar
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* Carrossel de Apps Recentes */}
      {!searchQuery && recentApps.length > 0 && (
        <section className="section">
          <div className="container">
            <h2 className="section-title">Aplicativos Recentes</h2>
            <Carousel apps={recentApps} />
          </div>
        </section>
      )}

      {/* Lista de Aplicativos */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">
            {searchQuery ? `Resultados para "${searchQuery}"` : 'Todos os Aplicativos'}
          </h2>
          
          {error && (
            <div className="alert alert-danger">
              {error}
            </div>
          )}

          {apps.length === 0 ? (
            <div className="text-center" style={{ padding: '40px' }}>
              <i className="fas fa-search" style={{ fontSize: '48px', color: '#ccc', marginBottom: '20px' }}></i>
              <h3 style={{ color: '#666', marginBottom: '10px' }}>
                {searchQuery ? 'Nenhum aplicativo encontrado' : 'Nenhum aplicativo disponível'}
              </h3>
              <p style={{ color: '#999' }}>
                {searchQuery 
                  ? 'Tente buscar com outros termos' 
                  : 'Seja o primeiro a publicar um aplicativo!'
                }
              </p>
            </div>
          ) : (
            <div className="app-grid">
              {apps.map(app => (
                <AppCard key={app.id} app={app} />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

export default Home;
